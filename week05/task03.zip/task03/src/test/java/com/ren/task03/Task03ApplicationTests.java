package com.ren.task03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
