package com.ren.task03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task03Application {

	public static void main(String[] args) {
		SpringApplication.run(Task03Application.class, args);
	}

}
