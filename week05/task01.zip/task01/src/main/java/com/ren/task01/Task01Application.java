package com.ren.task01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task01Application {

	public static void main(String[] args) {
		SpringApplication.run(Task01Application.class, args);
	}

}
