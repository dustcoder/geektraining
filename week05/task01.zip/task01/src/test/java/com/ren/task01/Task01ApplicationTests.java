package com.ren.task01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
